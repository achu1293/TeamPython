#REQUIREMENT 3 

class showroom:
    def __init__(self,id,name,email,brand,city):
        self.__id=id
        self.__name=name
        self.__email=email
        self.__brand=brand
        self.__city=city
    def setid(self,id):
        self.__id=id
    def getid(self):
        self.__id=id
    def setname(self,name):
        self.__name=name
    def getname(self):
        self.__name=name
    def setemail(self,email):
        self.__email=email
    def getemail(self):
        self.__email=email
    def setbrand(self,brand):
        self.__brand=brand
    def getbrand(self):
        self.__brand=brand
    def setcity(self,city):
        self.__city=city
    def getcity(self):
        self.__city=city
    def count(self,l2):
        l=[]
        l1=[]
        l4=[]
        for i in l2:
            l.append(i.__city)
        #print(l)
        for j in l:
            if j not in l1:
                l1.append(j)
        l1.sort()
        #print(l1)
        print("City{0:11}Count".format(" "))
        for i in l1:
            print(i,(15-len(i))* " ",l.count(i))
l2=[]
a=int(input("No.of showrooms:\n"))
for i in range(0,a):
    id,name,email,brand,city=input().split(',',4)
    obj=showroom(id,name,email,brand,city)
    l2.append(obj)
obj.count(l2)

