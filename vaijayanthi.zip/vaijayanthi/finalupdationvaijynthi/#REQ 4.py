#REQUIREMENT 4

class bike:
    def __init__(self,VIN,brand,model,engineDisplacement,brakeSystem,cost):
        self.__VIN=VIN
        self.__brand=brand
        self.__model=model
        self.__engineDisplacement=engineDisplacement
        self.__brakeSystem=brakeSystem
        self.__cost=cost
    def setVIN(self,VIN):
        self.__VIN=VIN
    def getVIN(self):
        self.__VIN=VIN
    def setbrand(self,brand):
        self.__brand=brand
    def getbrand(self):
        self.__brand=brand
    def setmodel(self,model):
        self.__model=model
    def getmodel(self):
        self.__model=model
    def setengineDisplacement(self,engineDisplacement):
        self.__engineDisplacement=engineDisplacement
    def getengineDisplacement(self):
        self.__engineDisplacement=engineDisplacement
    def setbrakeSystem(self,brakeSystem):
        self.__brakeSystem=brakeSystem
    def getbrakeSystem(self):
        self.__brakeSystem=brakeSystem
    def setcost(self,cost):
        self.__cost=cost
    def getcost(self):
        self.__cost=cost
    def __repr__(self):
        return("\nVIN:"+self.__VIN+"\nBrand:"+self.__brand+"\nModel:"+self.__model+"\nengineDisplacement:"+self.__engineDisplacement+"\nbrakeSystem:"+self.__brakeSystem+"\nCost:"+str(self.__cost))
    @classmethod
    def sort1(cls,brand1,det):
        uni=set(brand1)
        v=len(brand1)
        k=len(uni)
        if v==k:
            sortdet=sorted(det,key=lambda i:i[1])
            print("VIN{0:17}".format(" "),"Brand{0:5}".format(" "), "Model{0:5}".format(" "),"Engine Displacement{0:1}".format(" "),"Brake System{0:1}".format(" "),"Cost")
            for i in sortdet:
                VIN,brand,model,engineDisplacement,brakeSystem,cost=i
                print(VIN,(19-len(VIN))* " ",brand,(9-len(brand))* " ",model,(9-len(model))* " ",engineDisplacement,(19-len(engineDisplacement))* " ",brakeSystem,(12-len(brakeSystem))* " ",cost)
                
class compare:
    @classmethod
    def sort1(cls,engineDis,det):
        #print(engineDis)

        uni=set(engineDis)
        v=len(engineDis)
        k=len(uni)
        if v==k:
            sortdet=sorted(det,key=lambda i:i[3])
            print("VIN{0:17}".format(" "),"Brand{0:5}".format(" "), "Model{0:5}".format(" "),"Engine Displacement{0:1}".format(" "),"Brake System{0:1}".format(" "),"Cost")
            for i in sortdet:
                VIN,brand,model,engineDisplacement,brakeSystem,cost=i
                print(VIN,(19-len(VIN))* " ",brand,(9-len(brand))* " ",model,(9-len(model))* " ",engineDisplacement,(19-len(engineDisplacement))* " ",brakeSystem,(12-len(brakeSystem))* " ",cost)


brand1=[]
engineDis=[]
det=[]
n=int(input("Enter the number of the bikes:\n"))
for i in range(0,n):
    emp=[]
    VIN,brand,model,engineDisplacement,brakeSystem,cost=input().split(",",5)
    emp.extend([VIN,brand,model,engineDisplacement,brakeSystem,cost])
    det.append(emp)
    brand1.append(brand)
    engineDis.append(engineDisplacement)
#print(brand1)
#print(engineDis)
opt=int(input("1. Sort by Brand: \n2. Sort By EngineDisplacement: \n"))
if(opt==1):
    bike.sort1(brand1,det)
elif(opt==2):
    compare.sort1(engineDis,det)
else:
    print("Invalid choice")          
          
