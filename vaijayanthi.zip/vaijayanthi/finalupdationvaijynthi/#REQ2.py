#REQUIREMENT 2.
#VALIDATING VIN.
import re
class bike:
    def __init__(self,VIN):
        self.__VIN=VIN
    def setVIN(self,VIN):
        self.__VIN=VIN
    def getVIN(self):
        self.__VIN=VIN
    def validateVIN(self):
        if re.findall("[A-Z0-9]{3}[A-Z]{2}[0-9]{1}[A-Z0-9]{1}[0-9]{2}[A-Z0-9]{2}[0-9]{6}$",self.__VIN):
            print("VIN is Valid")
        else:
            print("VIN is Invalid")
print("Enter the VIN to be validated")
VIN=input()
obj1=bike(VIN)
obj1.validateVIN()

