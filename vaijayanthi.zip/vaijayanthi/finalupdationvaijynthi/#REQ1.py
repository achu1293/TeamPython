
#REQUIREMENT 1.
#COMPARING BIKES WHETHER SAME OR DIFF.

class bike:
    def __init__(self,VIN,brand,model,engineDisplacement,brakeSystem,cost): #PARAMETTRIZED CONSTRUCTORS
        self.__VIN=VIN
        self.__brand=brand
        self.__model=model
        self.__engineDisplacement=engineDisplacement
        self.__brakeSystem=brakeSystem
        self.__cost=cost
#USING GETTERS AND SETTERS
    def setVIN(self,VIN):
        self.__VIN=VIN
    def getVIN(self):
        self.__VIN=VIN
    def setbrand(self,brand):
        self.__brand=brand
    def getbrand(self):
        self.__brand=brand
    def setmodel(self,model):
        self.__model=model
    def getmodel(self):
        self.__model=model
    def setengineDisplacement(self,engineDisplacement):
        self.__engineDisplacement=engineDisplacement
    def getengineDisplacement(self):
        self.__engineDisplacement=engineDisplacement
    def setbrakeSystem(self,brakeSystem):
        self.__brakeSystem=brakeSystem
    def getbrakeSystem(self):
        self.__brakeSystem=brakeSystem
    def setcost(self,cost):
        self.__cost=cost
    def getcost(self):
        self.__cost=cost
    def __repr__(self):
        return("VIN:"+self.__VIN+"\nBrand:"+self.__brand+"\nModel:"+self.__model+"\nengineDisplacement:"+self.__engineDisplacement+"\nbrakeSystem:"+self.__brakeSystem+"\nCost:"+str(self.__cost))
    def __eq__(self,other):
        if(self.__VIN,self.__brand)==(other.__VIN,other.__brand):
            return("\nBike1 is same as Bike2")
        else:
            return("\nBoth Bike1 and Bike2 are different")
    
   
print("Bike1 Details:")
VIN,brand,model,engineDisplcement,brakeSystem,cost=input().split(",",5)
cost=float(cost)
cost=round(cost,1)
obj1=bike(VIN,brand,model,engineDisplcement,brakeSystem,cost)
print("Bike2 Details:")
VIN,brand,model,engineDisplcement,brakeSystem,cost=input().split(",",5)
cost=float(cost)
cost=round(cost,1)
obj2=bike(VIN,brand,model,engineDisplcement,brakeSystem,cost)
print("\nBike 1")
print(obj1)
print("\nBike 2")
print(obj2)
print(obj1==obj2)



