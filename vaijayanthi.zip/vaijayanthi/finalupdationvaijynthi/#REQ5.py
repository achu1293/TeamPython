

#REQUIREMENT 5
#CHECKING THE BIKE DETAILS WHERE THE GIVEN COST AND ENGDIS ARE SAME

class bike:
       def __init__(self,VIN,brand,model,engineDisplacement,brakeSystem,cost):
           self.__VIN=VIN
           self.__brand=brand
           self.__model=model
           self.__engineDisplacement=engineDisplacement
           self.__brakeSystem=brakeSystem
           self.__cost=cost
#GETTERS AND SETTERS
       def setVIN(self,VIN):
           self.__VIN=VIN
       def getVIN(self):
           return self.__VIN
       def setbrand(self,brand):
           self.__brand=brand
       def getbrand(self):
           return self.__brand
       def setmodel(self,model):
            self.__model=model
       def getmodel(self):
           return self.__model
       def setengineDisplacement(self,engineDisplacement):
           self.__engineDisplacement=engineDisplacement
       def getengineDisplacement(self):
           return self.__engineDisplacement
       def setbrakeSystem(self,brakeSystem):
           self.__brakeSystem=brakeSystem
       def getbrakeSystem(self):
           return self.__brakeSystem
       def setcost(self,cost):
           self.__cost=cost
       def getcost(self):
           return self.__cost
#NEW CLASS TO CHECK ENGDIS AMD COST
class BikeBO(bike):
       def __init__(self,VIN,brand,model,engineDisplacement,brakeSystem,cost):
           super().__init__(VIN,brand,model,engineDisplacement,brakeSystem,cost)
#method to check enginedisplacement
       def checkEngDis(self,l):
           l1=[]
           l3=[]
           final=[]
           for i in l:
               l2=[i.getVIN(),i.getbrand(),i.getmodel(),i.getengineDisplacement(),i.getbrakeSystem(),i.getcost()]
               #print("l2",l2)
               l1.append(l2)
               #print("l1",l1)
               engdis=[i.getengineDisplacement()]
               l3.extend(engdis)
               #print("l3",l3)
         
           if ED in l3:
               print("VIN{0:17}".format(" "),"Brand{0:5}".format(" "), "Model{0:5}".format(" "),"Engine Displacement{0:1}".format(" "),"Brake System{0:1}".format(" "),"Cost")
               v=len(l3)
               for i in range(0,v):
                     if ED == l3[i]:
                         final.append(l1[i])
                         #print(final)
               for i in final:
                     VIN,brand,model,engineDisplacement,brakeSystem,cost=i
                     print(VIN,(19-len(VIN))* " ",brand,(9-len(brand))* " ",model,(9-len(model))* " ",engineDisplacement,(19-len(engineDisplacement))* " ",brakeSystem,(12-len(brakeSystem))* " ",cost)
           else:
               print("No such bike is present")
#method to search cost
       def searchcost(self,l):
            c=0
            l1=[]
            l3=[]
            final=[]
            for i in l:
                l2=[i.getVIN(),i.getbrand(),i.getmodel(),i.getengineDisplacement(),i.getbrakeSystem(),i.getcost()]
                #print(l2)
                l1.append(l2)
                #print("l1",l1)
                cost1=[i.getcost()]
                l3.extend(cost1)
                #print("l3",l3)
           
            for i in range(0,len(l3)):
                if l3[i]<=costgn:
                    final.append(l1[i])
                    #print("fin",final)
                
                elif l3[i]!=costgn and l3[i]>costgn:
                    c=c+1
            if c==len(l3):
                print("No such bike is present")
            else:
                print("VIN{0:17}".format(" "),"Brand{0:5}".format(" "), "Model{0:5}".format(" "),"Engine Displacement{0:1}".format(" "),"Brake System{0:1}".format(" "),"Cost") 
                
            for i in final:
                VIN,brand,model,engineDisplacement,brakeSystem,cost=i
                print(VIN,(19-len(VIN))* " ",brand,(9-len(brand))* " ",model,(9-len(model))* " ",engineDisplacement,(19-len(engineDisplacement))* " ",brakeSystem,(12-len(brakeSystem))* " ",cost)         
                   
                   
     



print("No.of bikes")
l=[]
a=int(input())
for i in range(0,a):
    VIN,brand,model,engineDisplacement,brakeSystem,cost=input().split(',',5)
    cost=float(cost)
    cost=round(cost,1)
    obj=BikeBO(VIN,brand,model,engineDisplacement,brakeSystem,cost)
    l.append(obj)
    #print(l)
opt=int(input("1.By Engine Displacement\n2. By Cost\n"))
if opt==1:
    print("Enter the engine Displacement: ")
    ED=input()
    obj.checkEngDis(l)
elif opt==2:
    print("Enter the cost:")
    costgn=float(input())
    obj.searchcost(l)
else:
    print("Invalid choice")

                
                     
                     
