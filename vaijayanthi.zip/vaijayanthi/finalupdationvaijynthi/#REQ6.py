
#REQUIREMENT 6
#TO FIND A BEST UNIQUE SHOWROOM

class Showroom:
    def __init__(self,id,name,email,brand,city):
        self.__id=id
        self.__name=name
        self.__email=email
        self.__brand=brand
        self.__city=city
    def setid(self,id):
        self.__id=id
    def getid(self,id):
        return self.__id
    def setname(self,name):
        self.__name=name
    def getname(self,name):
        return self.__name
    def setemail(self,email):
        self.__email=email
    def getemail(self,email):
        return self.__email
    def setbrand(self,brand):
        self.__brand=brand
    def getbrand(self,brand):
        return self.__brand
    def setcity(self,city):
        self.__city=city
    def getcity(self,city):
        return self.__city

#inheriting base class prop
class bike(Showroom):
       def __init__(self,VIN,brand,model,engineDisplacement,brakeSystem,cost):
           self.__VIN=VIN
           self.__brand=brand
           self.__model=model
           self.__engineDisplacement=engineDisplacement
           self.__brakeSystem=brakeSystem
           self.__cost=cost
       def setVIN(self,VIN):
           self.__VIN=VIN
       def getVIN(self):
           return self.__VIN
       def setbrand(self,brand):
           self.__brand=brand
       def getbrand(self):
           return self.__brand
       def setmodel(self,model):
            self.__model=model
       def getbrand(self):
           return self.__model
       def setengineDisplacement(self,engineDisplacement):
           self.__engineDisplacement=engineDisplacement
       def getengineDisplacement(self):
           return self.__engineDisplacement
       def setbrakeSystem(self,brakeSystem):
           self.__brakeSystem=brakeSystem
       def getbrakeSystem(self):
           return self.__brakeSystem
       def setcost(self,cost):
           self.__cost=cost
       def getcost(self):
           return self.__cost
#checking unique enginedisplacements
       def bestShowroom(self,l):
           l2=[]
           l4=[]
           for i in range(len(l)):
               a=l[i]
               l3=[]
               for i in a:
                   l3.append(i.__engineDisplacement)
               l2.append(l3)       
           #print("l2",l2)
           for k in l2:
               m=len(set(k))
               l4.append(m)
           #print(l4)
           max1=l4.index(max(l4))
           
           return n[max1]
               
s=int(input("Enter the number of showrooms\n"))

n=[]
l=[]
for i in range(0,s):
    print("Enter the showroom details:")
    id,name,email,brand,city=input().split(",",4)
    obj=Showroom(id,name,email,brand,city)
    n.append(name)
    #print("name",n)
    print("Enter the number of bikes:")
    nob=int(input())
    l1=[]
    for i in range(0,nob):
        VIN,brand,model,engineDisplacement,brakeSystem,cost=input().split(",",5)
        cost=float(cost)
        cost=round(cost,1)
        obj1=bike(VIN,brand,model,engineDisplacement,brakeSystem,cost)
        l1.append(obj1)
    l.append(l1)
print("The best showroom is",bike.bestShowroom(n,l))
